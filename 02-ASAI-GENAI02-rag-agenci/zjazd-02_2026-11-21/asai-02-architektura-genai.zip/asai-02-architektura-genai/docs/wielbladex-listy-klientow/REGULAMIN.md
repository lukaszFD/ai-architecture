# Zasady zmian i zwrotów – wyciąg z umowy Wielbłądex

Wyciąg z umowy o udział w imprezie turystycznej Wielbłądex
(wzór: `umowa_Wielbladek_Rowerem_przez_Afryke_v2.docx`).
Jeśli umowa uczestnika ma inne zapisy, pierwszeństwo ma umowa.

## Przesunięcie terminu (§ 8 umowy)

- **Kiedy:** jeśli na 30 dni przed rozpoczęciem imprezy liczba zgłoszeń wynosi mniej niż 8 osób,
  Organizator może zamiast rozwiązać umowę przesunąć termin imprezy.
- **O ile:** najwyżej o 2 miesiące w stosunku do terminu z § 2.
- **Powiadomienie:** na trwałym nośniku, najpóźniej 20 dni przed pierwotną datą rozpoczęcia.
  Powiadomienie musi zawierać: nowy termin, przyczynę zmiany oraz skutki braku odpowiedzi.
- **Decyzja uczestnika:** w ciągu 7 dni od otrzymania powiadomienia uczestnik może przyjąć
  nowy termin albo odstąpić od umowy bez opłaty. Brak odpowiedzi oznacza przyjęcie nowego terminu.
- **Zwrot:** po odstąpieniu Organizator zwraca wszystkie wpłaty w ciągu 14 dni.
- **Cena i świadczenia:** przesunięcie nie podnosi ceny i nie zmniejsza zakresu świadczeń.
  Travel Concierge pomaga zmienić rezerwacje lotów, wizy i ubezpieczenie.
- **Tylko raz:** termin można przesunąć jeden raz. Jeśli w nowym terminie także nie zbierze się
  grupa co najmniej 8 osób, Organizator rozwiązuje umowę i w ciągu 14 dni zwraca wszystkie wpłaty
  bez potrąceń.

## Rozwiązanie umowy przez Organizatora (§ 7 ust. 4)

- Organizator może rozwiązać umowę, jeżeli liczba zgłoszeń jest mniejsza niż minimalna,
  powiadamiając uczestnika najpóźniej 20 dni przed rozpoczęciem imprezy.
- Zwraca wtedy wszystkie wpłaty, bez odszkodowania.

## Odstąpienie przez uczestnika (§ 7 ust. 1–3)

- Uczestnik może odstąpić od umowy w każdym czasie przed rozpoczęciem imprezy;
  Organizator może żądać opłaty według tabeli w Załączniku nr 2.
- Bez opłaty – przy nieuniknionych i nadzwyczajnych okolicznościach w miejscu docelowym.
- Uczestnik może przenieść uprawnienia na inną osobę, zawiadamiając Organizatora
  najpóźniej 7 dni przed rozpoczęciem imprezy.

## Kontakt

Biuro Podróży Wielbłądex · www.wielbladex.pl · tel. 600 000 000
