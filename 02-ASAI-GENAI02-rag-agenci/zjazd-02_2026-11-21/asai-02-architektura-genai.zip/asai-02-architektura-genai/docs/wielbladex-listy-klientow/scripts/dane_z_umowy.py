#!/usr/bin/env python3
"""Wyciąga z umowy Wielbłądex (.docx) dane potrzebne do listu do uczestnika.

Użycie:
    python scripts/dane_z_umowy.py umowa.docx [--przesun-miesiace N]

Wynik: JSON na standardowym wyjściu. Działa bez dodatkowych bibliotek
(czyta word/document.xml bezpośrednio z pliku .docx).
"""
import argparse
import calendar
import json
import re
import sys
import zipfile
from datetime import date, timedelta
from xml.etree import ElementTree as ET

W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def akapity(sciezka):
    """Zwraca listę niepustych akapitów (także z komórek tabel) w kolejności z dokumentu."""
    with zipfile.ZipFile(sciezka) as z:
        root = ET.fromstring(z.read("word/document.xml"))
    wynik = []
    for p in root.iter(f"{W}p"):
        tekst = "".join(t.text or "" for t in p.iter(f"{W}t")).strip()
        if tekst:
            wynik.append(re.sub(r"\s+", " ", tekst))
    return wynik


def po_etykiecie(lista, etykieta):
    """Wartość z tabeli „etykieta | wartość” – akapit następujący po etykiecie."""
    for i, a in enumerate(lista[:-1]):
        if a.lower() == etykieta.lower():
            return lista[i + 1]
    return None


def data_pl(s):
    d, m, r = (int(x) for x in s.split("."))
    return date(r, m, d)


def plus_miesiace(d, n):
    m = d.month - 1 + n
    r, m = d.year + m // 12, m % 12 + 1
    return date(r, m, min(d.day, calendar.monthrange(r, m)[1]))


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("umowa", help="plik umowy .docx")
    ap.add_argument("--przesun-miesiace", type=int, default=None,
                    help="o ile miesięcy przesunąć termin (wylicza nowy termin o tej samej długości)")
    args = ap.parse_args()

    tekst = akapity(args.umowa)
    calosc = "\n".join(tekst)

    # uczestnik: pierwszy akapit zaczynający się od „Pani” albo „Pan” po nagłówku PODRÓŻNY
    uczestnik, zwrot = None, None
    for a in tekst:
        m = re.match(r"^(Pani|Pan)\s+(.+)$", a)
        if m:
            zwrot = "Szanowna Pani" if m.group(1) == "Pani" else "Szanowny Panie"
            uczestnik = m.group(2).strip()
            break

    termin_txt = po_etykiecie(tekst, "Termin imprezy")
    termin = None
    if termin_txt:
        m = re.search(r"(\d{2}\.\d{2}\.\d{4})\s*[–-]\s*(\d{2}\.\d{2}\.\d{4})", termin_txt)
        if m:
            od, do = data_pl(m.group(1)), data_pl(m.group(2))
            termin = {"od": od.strftime("%d.%m.%Y"), "do": do.strftime("%d.%m.%Y"), "dni": (do - od).days + 1}

    grupa = po_etykiecie(tekst, "Wielkość grupy") or ""
    m = re.search(r"minimalna liczba uczestników:\s*(\d+)", grupa)
    min_uczestnikow = int(m.group(1)) if m else None

    # paragraf o przesunięciu terminu (w wersji v2 umowy: § 8)
    przes = {"jest": False, "paragraf": None, "maks_miesiecy": None}
    m = re.search(r"(§\s*\d+)\s+PRZESUNIĘCIE TERMINU", calosc)
    if m:
        przes["jest"] = True
        przes["paragraf"] = m.group(1)
        mm = re.search(r"nie więcej niż o (\d+) miesiąc", calosc)
        przes["maks_miesiecy"] = int(mm.group(1)) if mm else None

    wynik = {
        "plik": args.umowa,
        "uczestnik": uczestnik,
        "zwrot_grzecznosciowy": zwrot,
        "impreza": po_etykiecie(tekst, "Nazwa imprezy"),
        "termin": termin,
        "wylot": po_etykiecie(tekst, "Wylot"),
        "cena": po_etykiecie(tekst, "Cena całkowita"),
        "min_uczestnikow": min_uczestnikow,
        "przesuniecie_terminu": przes,
        "braki": [],
        "ostrzezenia": [],
    }

    for pole in ("uczestnik", "impreza", "termin"):
        if not wynik[pole]:
            wynik["braki"].append(pole)
    if min_uczestnikow is None:
        wynik["braki"].append("min_uczestnikow (w umowie brak liczby albo pole [do uzupełnienia])")

    if args.przesun_miesiace is not None:
        if not przes["jest"]:
            wynik["ostrzezenia"].append("Umowa nie przewiduje przesunięcia terminu – przekaż sprawę opiekunowi klienta.")
        elif przes["maks_miesiecy"] and args.przesun_miesiace > przes["maks_miesiecy"]:
            wynik["ostrzezenia"].append(f"Przesunięcie o {args.przesun_miesiace} mies. przekracza limit z umowy "
                                        f"({przes['maks_miesiecy']} mies.).")
        if termin:
            nowy_od = plus_miesiace(data_pl(termin["od"]), args.przesun_miesiace)
            nowy_do = nowy_od + timedelta(days=termin["dni"] - 1)
            wynik["nowy_termin"] = {"od": nowy_od.strftime("%d.%m.%Y"), "do": nowy_do.strftime("%d.%m.%Y"),
                                    "dni": termin["dni"]}

    json.dump(wynik, sys.stdout, ensure_ascii=False, indent=2)
    print()
    return 1 if wynik["braki"] else 0


if __name__ == "__main__":
    sys.exit(main())
