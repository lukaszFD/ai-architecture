# Wzory listów do uczestników

Pola w nawiasach klamrowych uzupełnij danymi z `scripts/dane_z_umowy.py`
i z polecenia. Zachowaj układ: najwyżej 3 akapity i podpis.
Akapit oznaczony [STAŁY KLIENT] dodaj tylko, gdy uczestnik był już
z nami na co najmniej 2 wyprawach – jako pierwsze zdanie listu.

---

## Zmiana terminu

**Temat:** Nowy termin wyprawy „{IMPREZA}”

{ZWROT_GRZECZNOSCIOWY} {IMIE_NAZWISKO},

[STAŁY KLIENT] Bardzo dziękujemy, że po raz kolejny wybiera Pani/Pan wyprawę z Wielbłądex –
to dla nas ważne. Z przykrością informujemy, że wyprawa „{IMPREZA}” zaplanowana na
{STARY_TERMIN} nie zebrała wymaganej minimalnej grupy {MIN_UCZESTNIKOW} osób.
Zgodnie z § 8 umowy przesuwamy ją na {NOWY_TERMIN}.

Cena i zakres świadczeń pozostają bez zmian, a nasz Travel Concierge pomoże przebukować
loty, wizy i ubezpieczenie. W ciągu 7 dni od otrzymania tego listu może Pani/Pan przyjąć
nowy termin albo odstąpić od umowy bez żadnej opłaty – wtedy zwrócimy wszystkie wpłaty
w ciągu 14 dni. Brak odpowiedzi w tym czasie oznacza przyjęcie nowego terminu.

Jeśli ma Pani/Pan pytania, jestem do dyspozycji. Z serdecznymi pozdrowieniami,

{IMIE_OPIEKUNA}, opiekun grupy
Biuro Podróży Wielbłądex · tel. 600 000 000

---

## Odwołanie imprezy

**Temat:** Odwołanie wyprawy „{IMPREZA}”

{ZWROT_GRZECZNOSCIOWY} {IMIE_NAZWISKO},

[STAŁY KLIENT] Dziękujemy za zaufanie i kolejną wspólną wyprawę w planach.
Z przykrością informujemy, że wyprawa „{IMPREZA}” w terminie {TERMIN} nie zebrała
wymaganej minimalnej grupy {MIN_UCZESTNIKOW} osób i musimy ją odwołać.

Zgodnie z umową zwrócimy wszystkie wpłaty w ciągu 14 dni, bez potrąceń, na rachunek,
z którego je otrzymaliśmy. Chętnie zaproponujemy inną wyprawę z naszej oferty.

Jeśli ma Pani/Pan pytania, jestem do dyspozycji. Z serdecznymi pozdrowieniami,

{IMIE_OPIEKUNA}, opiekun grupy
Biuro Podróży Wielbłądex · tel. 600 000 000
