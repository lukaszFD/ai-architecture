# Wielbłądex – plany wycieczek

**Afryka szyta na miarę.** Wyprawy dla małych grup do 10 osób z polskojęzycznym pilotem. Poniżej opisujemy trasy dzień po dniu – to punkt wyjścia, który zmieniamy pod Wasze tempo i zainteresowania.

Cztery pierwsze wycieczki pochodzą z ulotki Wielbłądex. Dwie kolejne – Kilimandżaro oraz Wodospady Wiktorii z deltą Okawango – dodaliśmy dla tych, którzy chcą połączyć Afrykę z górami albo z wodą. Każdą trasę można wydłużyć, skrócić do minimum 10 dni albo połączyć z inną.

## Spis tras

| Wycieczka | Region | Długość | Najlepszy termin | Cena od* |
|---|---|---|---|---|
| [Rowerem przez Afrykę](#row) | RPA, Botswana, Zambia | 14 dni; warianty: 14 / 21 / 28 dni | maj–październik (pora sucha) | 14 210 zł |
| [Z plecakiem w Serengeti](#ser) | Tanzania | 10 dni; warianty: 10 / 14 / 18 dni | styczeń–marzec i czerwiec–październik | 14 250 zł |
| [Afryka w obiektywie](#kru) | Park Krugera, RPA | 10 dni; warianty: 10 / 12 / 16 dni | maj–wrzesień (zwierzęta przy wodopojach) | 13 965 zł |
| [Afryka codziennie](#mas) | Masai Mara, Kenia | 10 dni; warianty: 10 / 14 / 21 dni | cały rok; migracja lipiec–październik | 12 065 zł |
| [Na dach Afryki – Kilimandżaro](#kil) | Tanzania | 10 dni; warianty: 10 / 12 / 14 dni | styczeń–marzec i czerwiec–październik | 14 250 zł |
| [Wodospady Wiktorii i delta Okawango](#oka) | Zambia, Zimbabwe, Botswana | 10 dni; warianty: 10 / 14 / 18 dni | czerwiec–październik (wysoka woda w delcie) | 15 675 zł |

\* Najtańszy wariant dla pary, cena za osobę (najkrótsza wycieczka, śniadania).

## Travel Concierge – w cenie każdej wycieczki

Osobisty asystent przed wyjazdem, w trakcie i po powrocie:

- wizy, szczepienia i ubezpieczenie
- loty, transfery i bagaż sprzętowy (rowery, sprzęt foto)
- rezerwacje i niespodzianki
- kontakt 24/7: telefon i WhatsApp

**Cena obejmuje:** przelot z Polski i z powrotem oraz loty lokalne z planu; noclegi w lodge’ach, hotelach i obozach namiotowych; polskojęzycznego pilota i lokalnych przewodników; transport, opłaty parkowe i atrakcje z planu; wybrany wariant wyżywienia; ubezpieczenie KL/NNW z bagażem sprzętowym.

**Cena nie obejmuje:** opłat wizowych i szczepień, napiwków i wydatków własnych, atrakcji oznaczonych „za dopłatą”.

Ceny pochodzą z cennika Wielbłądex (`wielbladex_cennik_wycieczek.xlsx`) i są orientacyjne. Ostateczną cenę podajemy po konsultacji trasy.

---

<a id="row"></a>

## Rowerem przez Afrykę

*Cały kontynent · RPA, Botswana, Zambia*

> Szutrowe drogi, wioski i horyzont bez końca. Dystans dobieramy do kondycji grupy, a bagaż jedzie za Wami autem.

| | |
|---|---|
| Plan dnia po dniu | 14 dni |
| Na rowerze | ok. 300–350 km, 40–70 km dziennie |
| Kondycja | średnia, szutry i piach |
| Najlepszy termin | maj–październik (pora sucha) |

Zaczynamy nad Limpopo, na styku trzech państw, i jedziemy na północ aż do Wodospadów Wiktorii. Na rowerze pokonujemy odcinki, które dobrze się jedzie: szutry przez farmy, ścieżki słoni w Mashatu, drogi wzdłuż panwi Makgadikgadi. Dłuższe i nudne odcinki pokonujemy autem technicznym, które wiezie też bagaże, wodę i zapasowe części. W parkach narodowych z dużymi drapieżnikami nie jeździmy na rowerze, tylko na safari samochodem lub łodzią.

### Ceny

| Długość | Para, za os. – śniadania | Para, za os. – śniadania + kolacje | Para, za os. – pełne wyżywienie | 1 osoba – śniadania | 1 osoba – pełne wyżywienie |
|---|--:|--:|--:|--:|--:|
| 14 dni | 14 210 zł | 15 410 zł | **16 205 zł** | 16 500 zł | **18 600 zł** |
| 21 dni | 18 635 zł | 20 430 zł | **21 625 zł** | 21 930 zł | **25 080 zł** |
| 28 dni | 23 055 zł | 25 450 zł | **27 045 zł** | 27 350 zł | **31 550 zł** |

### Plan dzień po dniu (14 dni)

**Dzień 1 – Wylot.** Lot z Polski do Johannesburga z przesiadką. Rower można zabrać własny – bagażem sprzętowym zajmuje się Concierge.

**Dzień 2 – Johannesburg – dolina Limpopo.** Przejazd autem na północ RPA, w okolice Parku Narodowego Mapungubwe. Składamy rowery i robimy krótki rozjazd na rozgrzewkę (ok. 20 km).

**Dzień 3 – Mapungubwe.** Rano park Mapungubwe (wpisany na listę UNESCO) i punkt widokowy na zbieg Limpopo i Szaszi – stąd widać jednocześnie RPA, Botswanę i Zimbabwe. Po południu 40 km szutrami między farmami.

**Dzień 4 – Granica w Pont Drift – Mashatu.** Przekraczamy granicę z Botswaną nad Limpopo. W rezerwacie Mashatu (Północne Tuli) pierwsza przejażdżka z przewodnikiem po starych ścieżkach słoni.

**Dzień 5 – Mashatu.** Jazda o świcie i przed zachodem słońca, w południe odpoczynek w obozie. Słonie, antylopy, czasem lwy – przewodnik prowadzi grupę i dobiera trasę do zwierząt.

**Dzień 6 – Serowe – Khama Rhino Sanctuary.** Przejazd autem w głąb Botswany. Po południu w rezerwacie Khama tropimy nosorożce białe pieszo i z samochodu.

**Dzień 7 – W stronę Makgadikgadi.** Ok. 60 km na rowerze szutrami przez wioski, resztę drogi pokonujemy autem. Nocleg w lodge’u na skraju panwi.

**Dzień 8 – Panwie Makgadikgadi.** Jazda po twardej krawędzi solnej panwi (tylko w porze suchej) i spotkanie z oswojonymi z ludźmi surykatkami. Wieczorem kolacja pod gołym niebem.

**Dzień 9 – Kasane – rzeka Chobe.** Długi przejazd autem na północ. Po południu rejs łodzią po Chobe: słonie przy wodopoju, hipopotamy, krokodyle.

**Dzień 10 – Park Chobe – Livingstone.** Poranne safari samochodem w parku Chobe. Przez most w Kazungula przejeżdżamy do Zambii, nocleg w Livingstone.

**Dzień 11 – Wioski wokół Livingstone.** Ok. 50 km lokalnymi drogami, przystanek w wiosce Mukuni i na targu. Lunch u miejscowej rodziny.

**Dzień 12 – Wodospady Wiktorii.** Spacer po ścieżkach przy wodospadach i przez most Knife-Edge. Od połowy sierpnia do połowy stycznia (zależnie od stanu wody) można dopłacić do kąpieli w Devil’s Pool.

**Dzień 13 – Zambezi – wylot.** Wolne przedpołudnie (rafting lub lot nad wodospadami za dopłatą), po południu rejs o zachodzie słońca. Wieczorem lot powrotny.

**Dzień 14 – Powrót.** Przylot do Polski.

### Dłuższe warianty

- **21 dni:** Dodatkowy odcinek przez Zimbabwe: wzgórza Matobo z malowidłami naskalnymi i Park Narodowy Hwange, do tego dzień odpoczynku co cztery dni jazdy.
- **28 dni:** Jak wariant 21-dniowy, a na koniec jazda pasem Zambezi w Namibii wzdłuż rzeki do Katima Mulilo. Ok. 700 km na rowerze.

### Warto wiedzieć

- Zabierz rękawiczki, okulary i krem z wysokim filtrem – w porze suchej rano jest chłodno, w południe gorąco.
- Rowery MTB z wypożyczalni są w cenie; własny przewieziemy jako bagaż sprzętowy.
- Gdy ktoś ma gorszy dzień, siada do auta technicznego i dołącza na kolejnym odcinku.

---

<a id="ser"></a>

## Z plecakiem w Serengeti

*Tanzania*

> Piesze trasy z rangerem, noce w obozach pod gwiazdami i Wielka Migracja widziana z bliska, a nie zza szyby.

| | |
|---|---|
| Plan dnia po dniu | 10 dni |
| Pieszo | 3–5 godzin dziennie w Serengeti |
| Kondycja | średnia, bez wspinaczki |
| Najlepszy termin | styczeń–marzec i czerwiec–październik |

Większość ludzi ogląda Serengeti z dachu land cruisera. My idziemy pieszo, w małej grupie, z przewodnikiem i uzbrojonym rangerem TANAPA. Pieszo wolno chodzić tylko w wyznaczonych strefach dzikiej przyrody, więc obóz stawiamy tam, gdzie akurat są stada. Od stycznia do marca to południe parku i równiny Ndutu (wtedy rodzą się młode gnu), w czerwcu i lipcu zachodni korytarz, a od lipca do października północ i przeprawy przez rzekę Mara.

### Ceny

| Długość | Para, za os. – śniadania | Para, za os. – śniadania + kolacje | Para, za os. – pełne wyżywienie | 1 osoba – śniadania | 1 osoba – pełne wyżywienie |
|---|--:|--:|--:|--:|--:|
| 10 dni | 14 250 zł | 15 105 zł | **15 675 zł** | 16 500 zł | **18 000 zł** |
| 14 dni | 17 955 zł | 19 150 zł | **19 950 zł** | 21 000 zł | **23 100 zł** |
| 18 dni | 21 660 zł | 23 200 zł | **24 225 zł** | 25 500 zł | **28 200 zł** |

### Plan dzień po dniu (10 dni)

**Dzień 1 – Wylot.** Lot z Polski na lotnisko Kilimandżaro (JRO), przejazd do Arushy.

**Dzień 2 – Park Narodowy Arusha.** Pierwszy marsz z rangerem: żyrafy, bawoły, małpy gerezy i jeziora Momella. Sprawdzamy buty, plecaki i tempo grupy.

**Dzień 3 – Ngorongoro – wąwóz Olduvai.** Przejazd przez obszar chroniony Ngorongoro z postojem w wąwozie Olduvai, gdzie znaleziono jedne z najstarszych śladów człowieka. Wieczorem pierwszy nocleg w namiotowym obozie.

**Dni 4–7 – Serengeti pieszo.** Cztery dni w strefie pieszych wędrówek. Wychodzimy o świcie, wracamy przed upałem; po południu krótsze wyjście albo safari samochodem. Wieczory przy ognisku, noce w namiotach z łóżkami i łazienką. Ranger opowiada, jak czytać tropy i jak zachować się przy bawołach czy słoniach.

**Dzień 8 – Krater Ngorongoro.** Całodzienne safari samochodem na dnie krateru (tu chodzić pieszo nie wolno). Duża szansa na nosorożce czarne.

**Dzień 9 – Karatu – wylot.** Rano spacer po plantacji kawy w Karatu, potem przejazd na lotnisko i lot powrotny.

**Dzień 10 – Powrót.** Przylot do Polski.

### Dłuższe warianty

- **14 dni:** Dodatkowo krater Empakaai (zejście pieszo nad jezioro na dnie) i jezioro Natron z widokiem na wulkan Ol Doinyo Lengai.
- **18 dni:** Wariant 14-dniowy plus cztery dni na Zanzibarze: Stone Town, plantacja przypraw i plaża na koniec.

### Warto wiedzieć

- W obozach w Serengeti jest zawsze pełne wyżywienie; wybrany wariant wyżywienia dotyczy noclegów w Arushy i Karatu.
- Ubrania w kolorach ziemi – bez bieli i jaskrawych barw (płoszą zwierzęta) i bez granatu (przyciąga muchy tse-tse).
- Lekkie, rozchodzone buty trekkingowe są ważniejsze niż sprzęt fotograficzny.

---

<a id="kru"></a>

## Afryka w obiektywie

*Park Krugera · RPA*

> Fotosafari z fotografem-przewodnikiem: Wielka Piątka o złotej godzinie, warsztaty w terenie i wieczorne omawianie zdjęć.

| | |
|---|---|
| Plan dnia po dniu | 10 dni |
| Grupa | do 8 osób w 2 autach – każdy ma miejsce przy oknie |
| Sprzęt | od smartfona po lustrzankę |
| Najlepszy termin | maj–wrzesień (zwierzęta przy wodopojach) |

Tę wycieczkę ułożyliśmy pod światło. Bramy Parku Krugera otwierają się o 5:30 latem i o 6:00 zimą – wtedy już na nie czekamy. W południe, gdy światło jest płaskie, jest czas na warsztaty i obróbkę zdjęć, a po południu wracamy w teren na złotą godzinę. Część pobytu spędzamy w prywatnym rezerwacie Sabi Sand, gdzie terenowe auto może zjechać z drogi za lampartem – w samym parku Krugera to niedozwolone.

### Ceny

| Długość | Para, za os. – śniadania | Para, za os. – śniadania + kolacje | Para, za os. – pełne wyżywienie | 1 osoba – śniadania | 1 osoba – pełne wyżywienie |
|---|--:|--:|--:|--:|--:|
| 10 dni | 13 965 zł | 14 820 zł | **15 390 zł** | 16 450 zł | **17 950 zł** |
| 12 dni | 15 820 zł | 16 845 zł | **17 530 zł** | 18 750 zł | **20 550 zł** |
| 16 dni | 19 525 zł | 20 890 zł | **21 805 zł** | 23 350 zł | **25 750 zł** |

### Plan dzień po dniu (10 dni)

**Dzień 1 – Wylot.** Lot z Polski do Johannesburga z przesiadką.

**Dzień 2 – Johannesburg – Hazyview.** Przejazd na wschód, do Mpumalangi. Wieczorem pierwsze spotkanie z fotografem: ustawienia aparatu na safari i plan tygodnia.

**Dzień 3 – Panorama Route.** Krajobrazy: kanion rzeki Blyde, Three Rondavels, God’s Window i kotły Bourke’s Luck. Warsztat z kompozycji i fotografii krajobrazu.

**Dni 4–6 – Park Krugera – południe.** Noclegi w obozach Skukuza i Lower Sabie. Codziennie poranne i popołudniowe safari w otwartym aucie, w południe zajęcia: ostrość na ruchome cele, ekspozycja pod światło, praca z długim obiektywem. O zachodzie słońca zapora Sunset Dam – hipopotamy, krokodyle i ptaki w złotym świetle.

**Dni 7–8 – Rezerwat Sabi Sand.** Lodge w prywatnym rezerwacie. Tropiciel prowadzi auto poza drogami, więc lamparta czy lwy można sfotografować z bliska i z dobrej strony. Nocne safari z reflektorem – warsztat zdjęć przy słabym świetle.

**Dzień 9 – Ostatnie safari – wylot.** Poranne safari i przegląd najlepszych zdjęć z całego wyjazdu. Przejazd do Johannesburga lub lot z Mpumalangi, wieczorem lot powrotny.

**Dzień 10 – Powrót.** Przylot do Polski. Po kilku dniach każdy dostaje od fotografa omówienie swoich 10 najlepszych zdjęć.

### Dłuższe warianty

- **12 dni:** Dwie noce więcej w centralnej części parku (Satara, Olifants): otwarte sawanny, więcej lwów i gepardów.
- **16 dni:** Wariant 12-dniowy plus Kapsztad: Przylądek Dobrej Nadziei, pingwiny na Boulders Beach i Góra Stołowa.

### Warto wiedzieć

- Najlepiej sprawdza się obiektyw 100–400 mm lub dłuższy; jeśli go nie masz, Concierge pomoże wypożyczyć.
- Zabierz worek z kaszą lub poduszkę pod obiektyw – w aucie zastępuje statyw.
- Rano bywa zimno (szczególnie od czerwca do sierpnia), więc ubierz się „na cebulkę”.

---

<a id="mas"></a>

## Afryka codziennie

*Masai Mara · Kenia*

> Dzień razem z Masajami: targ, wypas bydła, wspólne gotowanie. Afryka bez filtra i bez pośpiechu.

| | |
|---|---|
| Plan dnia po dniu | 10 dni |
| Tempo | spokojne, bez codziennych przejazdów |
| Kondycja | niewymagająca |
| Najlepszy termin | cały rok; migracja lipiec–październik |

Większość tej wycieczki spędzamy w jednym miejscu: w obozie na terenie konserwancji należącej do masajskich rodzin, tuż przy rezerwacie Masai Mara. Opłata za nocleg trafia częściowo do właścicieli ziemi. Gospodarze pokazują, jak wygląda ich zwykły dzień – od wypasu krów o świcie po kolację przy ogniu. Na safari też jeździmy, ale bez gonitwy od zwierzęcia do zwierzęcia.

### Ceny

| Długość | Para, za os. – śniadania | Para, za os. – śniadania + kolacje | Para, za os. – pełne wyżywienie | 1 osoba – śniadania | 1 osoba – pełne wyżywienie |
|---|--:|--:|--:|--:|--:|
| 10 dni | 12 065 zł | 12 920 zł | **13 490 zł** | 14 000 zł | **15 500 zł** |
| 14 dni | 14 970 zł | 16 170 zł | **16 965 zł** | 17 580 zł | **19 680 zł** |
| 21 dni | 20 060 zł | 21 855 zł | **23 050 zł** | 23 850 zł | **27 000 zł** |

### Plan dzień po dniu (10 dni)

**Dzień 1 – Wylot.** Lot z Polski do Nairobi.

**Dzień 2 – Nairobi.** Rano sierociniec słoni Sheldrick Wildlife Trust w porze karmienia słoniąt, potem Giraffe Centre. Wieczorem kolacja i rozmowa o tym, jak zachowywać się w masajskiej wiosce.

**Dzień 3 – Dolina Ryftowa – Masai Mara.** Przejazd z przystankiem na punkcie widokowym nad Wielkim Rowem Afrykańskim. Po południu powitanie w obozie w konserwancji.

**Dzień 4 – Wypas bydła.** O świcie wychodzimy z pasterzami i stadem. Po drodze uczymy się nazw roślin, z których Masajowie robią lekarstwa, i tego, jak czytać ślady zwierząt. Po południu odpoczynek, wieczorem ognisko.

**Dzień 5 – Targ i wspólne gotowanie.** Jedziemy z gospodarzami na lokalny targ (dzień targowy ustalamy na miejscu) i kupujemy produkty na wieczór. Gotujemy razem w obozie; kobiety z wioski uczą robić biżuterię z koralików.

**Dzień 6 – Safari w Masai Mara.** Cały dzień w rezerwacie z lunchem piknikowym. Od lipca do października jedziemy nad rzekę Mara – może trafimy na przeprawę gnu.

**Dzień 7 – Dzień w wiosce.** Wizyta w szkole (dzieci zawsze pytają o Polskę), spacer z masajskim wojownikiem, wieczorem tańce i opowieści starszyzny.

**Dzień 8 – Jezioro Naivasha.** Przejazd nad jezioro Naivasha, rejs łodzią do hipopotamów i spacer po Crescent Island między żyrafami i zebrami.

**Dzień 9 – Nairobi – wylot.** Powrót do Nairobi, czas na zakupy na targu rękodzieła, wieczorem lot powrotny.

**Dzień 10 – Powrót.** Przylot do Polski.

### Dłuższe warianty

- **14 dni:** Dodatkowo park Amboseli – słonie na tle Kilimandżaro – i dzień rowerem po Hell’s Gate, gdzie zwierzęta pasą się przy drodze.
- **21 dni:** Wariant 14-dniowy plus tydzień nad Oceanem Indyjskim: plaża Diani i stare miasto na wyspie Lamu.

### Warto wiedzieć

- Zanim zrobisz komuś zdjęcie, zapytaj – pilot pomoże w tłumaczeniu.
- Drobne prezenty dla szkoły (zeszyty, kredki) przekazujemy przez nauczycieli, nie rozdajemy dzieciom na ulicy.
- W konserwancji wieczorami bywa chłodno – przyda się polar.

---

<a id="kil"></a>

## Na dach Afryki – Kilimandżaro

*Tanzania · propozycja dodatkowa*

> Wejście na Uhuru Peak (5895 m n.p.m.) trasą Machame, z aklimatyzacją, tragarzami i kucharzem.

| | |
|---|---|
| Plan dnia po dniu | 10 dni |
| Na szlaku | 7 dni, ok. 60 km |
| Kondycja | dobra; doświadczenie górskie mile widziane |
| Najlepszy termin | styczeń–marzec i czerwiec–październik |

Na Kilimandżaro nie trzeba umieć się wspinać, ale trzeba się zaaklimatyzować. Dlatego wybieramy siedmiodniowy wariant trasy Machame: trzeciego dnia podchodzimy do Lava Tower (4600 m) i schodzimy spać niżej, do Barranco. Przewodnicy dwa razy dziennie mierzą każdemu saturację i puls. Namioty, jedzenie i większość bagażu niosą tragarze.

### Ceny

| Długość | Para, za os. – śniadania | Para, za os. – śniadania + kolacje | Para, za os. – pełne wyżywienie | 1 osoba – śniadania | 1 osoba – pełne wyżywienie |
|---|--:|--:|--:|--:|--:|
| 10 dni | 14 250 zł | 15 105 zł | **15 675 zł** | 16 250 zł | **17 750 zł** |
| 12 dni | 16 105 zł | 17 130 zł | **17 815 zł** | 18 450 zł | **20 250 zł** |
| 14 dni | 17 955 zł | 19 150 zł | **19 950 zł** | 20 650 zł | **22 750 zł** |

### Plan dzień po dniu (10 dni)

**Dzień 1 – Wylot.** Lot z Polski na lotnisko Kilimandżaro, przejazd do Moshi.

**Dzień 2 – Moshi.** Odpoczynek po podróży, odprawa z przewodnikiem i przegląd sprzętu. Brakujące rzeczy wypożyczymy na miejscu.

**Dzień 3 – Machame Gate – Machame Camp.** Start z 1800 m, marsz przez las deszczowy do obozu na ok. 3000 m.

**Dzień 4 – Shira Camp.** Wychodzimy ponad las, na płaskowyż Shira (ok. 3850 m). Pierwszy widok na szczyt.

**Dzień 5 – Lava Tower – Barranco.** Podejście na 4600 m i zejście na nocleg na ok. 3950 m – najważniejszy dzień aklimatyzacji.

**Dzień 6 – Ściana Barranco – Karanga.** Łatwa wspinaczka po ścianie Barranco (ręce się przydają, lina nie) i krótki etap do obozu Karanga.

**Dzień 7 – Barafu Camp.** Podejście do obozu szturmowego na 4673 m. Wcześnie kolacja i sen.

**Dzień 8 – Uhuru Peak – Mweka.** Wyjście ok. północy, na szczycie o wschodzie słońca. Potem długie zejście do obozu Mweka (ok. 3100 m).

**Dzień 9 – Mweka Gate – wylot.** Zejście do bramy, wręczenie certyfikatów, prysznic w hotelu i wieczorny lot powrotny.

**Dzień 10 – Powrót.** Przylot do Polski.

### Dłuższe warianty

- **12 dni:** Dłuższa i spokojniejsza trasa Lemosho (8 dni na szlaku) – lepsza aklimatyzacja, mniej ludzi.
- **14 dni:** Wariant 12-dniowy plus dwa dni safari w parku Tarangire i kraterze Ngorongoro.

### Warto wiedzieć

- Na szlaku zawsze jest pełne wyżywienie przygotowane przez kucharza; wybrany wariant dotyczy hotelu w Moshi.
- Napiwki dla tragarzy i przewodników są zwyczajem – ile zwykle się daje, podpowie Concierge.
- Przed wyjazdem zrób badania u lekarza i porozmawiaj z nim o chorobie wysokościowej.

---

<a id="oka"></a>

## Wodospady Wiktorii i delta Okawango

*Zambia · Zimbabwe · Botswana · propozycja dodatkowa*

> Wodospady z obu stron granicy, park Chobe z łodzi i delta Okawango z wydrążonego czółna mokoro.

| | |
|---|---|
| Plan dnia po dniu | 10 dni |
| Przeloty lokalne | Kasane – Maun |
| Kondycja | niewymagająca |
| Najlepszy termin | czerwiec–październik (wysoka woda w delcie) |

W trzech krajach widzimy trzy różne oblicza wody: huk Wodospadów Wiktorii, szeroką rzekę Chobe pełną słoni i ciche kanały delty Okawango. W delcie przez dwa dni pływamy czółnami mokoro, a na wyspach chodzimy pieszo z miejscowym przewodnikiem.

### Ceny

| Długość | Para, za os. – śniadania | Para, za os. – śniadania + kolacje | Para, za os. – pełne wyżywienie | 1 osoba – śniadania | 1 osoba – pełne wyżywienie |
|---|--:|--:|--:|--:|--:|
| 10 dni | 15 675 zł | 16 530 zł | **17 100 zł** | 18 500 zł | **20 000 zł** |
| 14 dni | 19 875 zł | 21 070 zł | **21 870 zł** | 23 720 zł | **25 820 zł** |
| 18 dni | 24 075 zł | 25 610 zł | **26 640 zł** | 28 940 zł | **31 640 zł** |

### Plan dzień po dniu (10 dni)

**Dzień 1 – Wylot.** Lot z Polski do Livingstone (Zambia) z przesiadką.

**Dzień 2 – Livingstone.** Przylot i odpoczynek. Wieczorem rejs po Zambezi o zachodzie słońca.

**Dzień 3 – Wodospady od strony Zambii.** Ścieżki przy wodospadach i most Knife-Edge. Od połowy sierpnia do połowy stycznia, gdy pozwala stan wody, można dopłacić do wyprawy na Livingstone Island i kąpieli w Devil’s Pool.

**Dzień 4 – Wodospady od strony Zimbabwe.** Przejście mostem granicznym na stronę Zimbabwe, skąd widać najszerszą panoramę wodospadów. Po południu wolny czas lub lot helikopterem za dopłatą.

**Dzień 5 – Kasane – rzeka Chobe.** Przejazd do Botswany. Po południu rejs łodzią po Chobe – dobry moment na zdjęcia słoni pijących wodę.

**Dzień 6 – Park Chobe – Maun.** Poranne safari samochodem, potem lot do Maun, bramy delty Okawango.

**Dni 7–8 – Delta Okawango.** Obóz na wyspie w delcie. Pływamy czółnami mokoro, chodzimy po wyspach pieszo, wieczorem siedzimy przy ognisku. Hipopotamy słychać całą noc.

**Dzień 9 – Lot nad deltą – wylot.** Rano (za dopłatą) widokowy lot awionetką nad deltą. Potem lot do Johannesburga i dalej do Polski.

**Dzień 10 – Powrót.** Przylot do Polski.

### Dłuższe warianty

- **14 dni:** Dodatkowo rezerwat Moremi i obszar Khwai – safari samochodem i nocne safari, dobre miejsce na dzikie psy.
- **18 dni:** Wariant 14-dniowy plus panwie Makgadikgadi i Nxai Pan: surykatki, baobaby Baines’a i nocleg pod gołym niebem na soli.

### Warto wiedzieć

- Przy wodospadach przyda się peleryna przeciwdeszczowa i wodoodporny worek na telefon – od lutego do maja mgła wodna moczy do suchej nitki.
- Na loty awionetkami obowiązuje limit bagażu (zwykle miękka torba do ok. 20 kg) – Concierge poda dokładne wymiary.
- Wymogi wizowe dla Zambii i Zimbabwe sprawdzi i załatwi Concierge.

---

## Pakiety i rabaty

Trasy można łączyć jedna po drugiej. Lecicie do Afryki raz, a między regionami przenosimy Was lotem lokalnym – stąd rabat.

### Gotowe pakiety

| Pakiet | Co obejmuje | Razem | Rabat | 1 osoba | Para (razem) |
|---|---|--:|--:|--:|--:|
| **Wielka Migracja** | Z plecakiem w Serengeti (10 dni) + Afryka codziennie (10 dni), pełne wyżywienie | 20 dni | 7% | 31 160 zł | **54 250 zł** |
| **Południe w obiektywie** | Afryka w obiektywie (10) + Wodospady Wiktorii i Okawango (10), śniadania i kolacje | 20 dni | 7% | 34 180 zł | **58 310 zł** |
| **Rower i safari** | Rowerem przez Afrykę (14) + Afryka w obiektywie (10), śniadania i kolacje | 24 dni | 7% | 32 650 zł | **56 230 zł** |
| **Afryka Wschodnia kompletna** | Kilimandżaro (10) + Serengeti (10) + Masai Mara (10), pełne wyżywienie | 30 dni | 12% | 45 100 zł | **78 920 zł** |
| **Wielki szlem Wielbłądex** | Rower (14) + Serengeti (10) + Kruger (10) + Masai Mara (10), pełne wyżywienie | 44 dni | 15% | 59 540 zł | **103 290 zł** |

Ceny po rabacie za łączenie. Klient z programem lojalnościowym dostaje dodatkowo swój rabat.

### Za łączenie wyjazdów

| Wycieczek w rezerwacji | Rabat |
|---|--:|
| 2 | 7% |
| 3 | 12% |
| 4 i więcej | 15% |

### Dla stałych klientów

| Poziom | Warunek | Rabat |
|---|---|--:|
| Brązowy | 1 wcześniejszy wyjazd | 3% |
| Srebrny | 2–3 wyjazdy | 5% |
| Złoty | 4–5 wyjazdów | 8% |
| Platynowy | 6+ wyjazdów lub ponad 60 000 zł | 10% |

### Zasady

- Rabaty za łączenie i lojalnościowy sumują się, ale łącznie wynoszą najwyżej 20%.
- Para śpi w pokoju dwuosobowym i dostaje 5% rabatu niezależnie od innych zniżek.
- Rabat za łączenie wymaga jednej rezerwacji i wycieczek następujących bezpośrednio po sobie.
- Rabaty nie obejmują opłat wizowych, szczepień ani dopłat za bagaż ponadnormatywny.

**Zaprojektujmy Twoją wyprawę, resztą zajmie się Concierge.** www.wielbladex.pl · tel. 600 000 000 · bezpłatna konsultacja trasy, online lub w biurze.

---

## Uwagi do materiału

- Ceny pochodzą z `wielbladex_cennik_wycieczek.xlsx` i opierają się na roboczych założeniach kosztowych, a nie na ofertach przewoźników czy lodge’y.
- Sprawdzone w sieci: rowerowe safari w Mashatu, piesze trasy w Serengeti z uzbrojonym rangerem TANAPA, sezon Devil’s Pool, godziny bram w parku Krugera. Pozostałe opisy atrakcji powstały bez weryfikacji.
- Propozycje oferty, a nie fakty z ulotki: kilometraż trasy rowerowej, grupa do 8 osób na fotosafari, omówienie zdjęć przez fotografa po powrocie.
- Wymogów wizowych i szczepień celowo nie podajemy – często się zmieniają; tekst odsyła do Concierge.

**Źródła:**

- [Cycle Mashatu (andBeyond)](https://www.andbeyond.com/experiences/africa/botswana/mashatu-game-reserve/cycle-mashatu/)
- [Travel Weekly – Tuli Block](https://www.travelweekly.com/Middle-East-Africa-Travel/Bike-safaris-in-elephant-lion-territory-Tuli-Block-Botswana?ct=afme)
- [Expert Africa – Serengeti Walking Mobile Camp](https://www.expertafrica.com/tanzania/serengeti-migration-area/serengeti-walking-mobile-camp/in-detail)
- [National Geographic – Serengeti](https://www.nationalgeographic.com/travel/article/serengeti-national-park-tanzania)
- [Devil’s Pool – sezonowość](https://www.mustseespots.com/zambia/articles/devils-pool-victoria-falls-seasonal-access-best-times-to-visit/)
- [SANParks – bramy parku Krugera](https://www.sanparks.org/parks/kruger/travel/entrance-gates)
- [Kruger – godziny bram](https://www.krugerpark.co.za/Kruger_Park_Travel_Advisory-travel/kruger-park-gate-times.html)
