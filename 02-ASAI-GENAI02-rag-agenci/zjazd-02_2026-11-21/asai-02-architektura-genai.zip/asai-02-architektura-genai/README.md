# asai-02-architektura-genai
ASAI-GENAI02 · Architektura aplikacji GenAI: RAG, agenci, tool use, orkiestracja · Dariusz Bielawski
