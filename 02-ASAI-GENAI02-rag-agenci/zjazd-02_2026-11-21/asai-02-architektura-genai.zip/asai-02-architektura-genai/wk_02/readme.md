# Wielbłądex – strona biura i zapisy na wyprawy

Aplikacja Flask z trzema stronami i REST API:

- **/** – strona informacyjna w stylu ulotki (`zjazd_01/wielbladex_ulotka_v2.png`): hasło „Afryka szyta na miarę”, Travel Concierge i karty sześciu wypraw,
- **/zapisy** – formularz zgłoszenia chęci udziału: dane osoby i kontakt, wycieczka i jej długość, preferowany termin, lotnisko wylotu, liczba osób, uwagi, zgoda RODO,
- **/zapisy/lista** – lista zapisanych osób z filtrem po wycieczce, edycją i usuwaniem; edycja otwiera ten sam formularz pod `/zapisy/<id>/edycja`.

Formularz i lista nie wysyłają danych bezpośrednio do stron, tylko rozmawiają z backendem przez REST API. Zapisy trafiają do bazy SQLite.

## Struktura

```
wk_02/
├── readme.md
├── pytest.ini
├── src/
│   ├── app.py                 # punkt startowy
│   ├── requirements.txt
│   └── wielbladex/
│       ├── __init__.py        # create_app()
│       ├── catalog.py         # wycieczki i lotniska
│       ├── validation.py      # walidacja formularza
│       ├── storage.py         # repozytorium SQLite
│       ├── api.py             # REST API (/api/...)
│       ├── views.py           # strony HTML
│       ├── templates/         # Jinja2
│       └── static/            # CSS, JS, logo
└── tests/                     # pytest
```

## Uruchomienie

Potrzebny jest Python 3.10 lub nowszy. Polecenia uruchamiasz z katalogu `wk_02`:

```bash
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r src/requirements.txt

cd src
python app.py
```

Strona działa pod adresem http://127.0.0.1:5000.

Zamiast `python app.py` możesz też użyć `flask --app app run --debug`, czyli trybu deweloperskiego z automatycznym przeładowaniem.

Zmienne środowiskowe (opcjonalne):

| Zmienna | Domyślnie | Znaczenie |
|---|---|---|
| `HOST` | `127.0.0.1` | adres nasłuchu (`0.0.0.0` udostępnia stronę w sieci) |
| `PORT` | `5000` | port |
| `FLASK_DEBUG` | – | `1` włącza tryb debug |
| `WIELBLADEX_DB` | `src/instance/wielbladex.sqlite3` | ścieżka do bazy SQLite |

Baza tworzy się sama przy pierwszym uruchomieniu.

## Testy

Z katalogu `wk_02`, przy aktywnym środowisku:

```bash
pytest
```

Testy (`tests/`) sprawdzają walidację, repozytorium SQLite, wszystkie metody API i renderowanie stron. Każdy test dostaje własną, tymczasową bazę.

## REST API

| Metoda | Ścieżka | Opis |
|---|---|---|
| GET | `/api/trips` | lista wycieczek (do wyboru w formularzu) |
| GET | `/api/trips/<id>` | jedna wycieczka |
| GET | `/api/airports` | lotniska wylotu |
| GET | `/api/registrations[?trip_id=<id>]` | lista zapisów, opcjonalnie dla jednej wycieczki |
| POST | `/api/registrations` | nowy zapis → `201` i nagłówek `Location` |
| GET | `/api/registrations/<id>` | jeden zapis |
| PUT | `/api/registrations/<id>` | zmiana całego zapisu (wszystkie pola, w tym `consent`) |
| PATCH | `/api/registrations/<id>` | zmiana wybranych pól |
| DELETE | `/api/registrations/<id>` | usunięcie zapisu → `204` |

Kody błędów: `400` (treść nie jest obiektem JSON), `404` (brak zasobu), `422` (błędy walidacji, w polu `fields` są komunikaty dla każdego pola).

Przykład:

```bash
curl -X POST http://127.0.0.1:5000/api/registrations \
  -H "Content-Type: application/json" \
  -d '{"first_name":"Janina","last_name":"Wielbłądek","email":"janina@example.com",
       "phone":"+48 600 000 000","trip_id":"rowerem-przez-afryke","duration":14,
       "preferred_date":"2027-06-01","departure_airport":"KTW","participants":2,
       "notes":"Własny rower","consent":true}'

curl -X PATCH http://127.0.0.1:5000/api/registrations/1 \
  -H "Content-Type: application/json" -d '{"participants":3}'
```

Reguły walidacji:

- wymagane pola: imię, nazwisko, e-mail, telefon, wycieczka, długość, termin, lotnisko i zgoda,
- długość musi być jednym z wariantów danej wycieczki, np. 14, 21 albo 28 dni dla trasy rowerowej,
- termin musi przypadać w przyszłości,
- liczba osób: od 1 do 10.

## Ograniczenia

To wersja szkoleniowa. Lista zapisów i jej edycja **nie mają logowania**, więc każdy, kto zna adres, widzi dane osobowe i może je zmienić. Przed publikacją trzeba dodać uwierzytelnianie panelu biura i uruchamiać aplikację na serwerze WSGI (np. gunicorn), a nie na serwerze deweloperskim Flaska.
