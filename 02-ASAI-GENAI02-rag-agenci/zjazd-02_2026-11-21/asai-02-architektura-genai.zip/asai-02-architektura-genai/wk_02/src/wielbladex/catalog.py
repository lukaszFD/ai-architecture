"""Katalog wycieczek i lotnisk wylotu.

Dane pochodzą z ulotki Wielbłądex (cztery pierwsze wycieczki) oraz z oferty
2027 (`docs/wielbladex_plany_wycieczek.md`), która dodaje dwie trasy.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class Trip:
    id: str
    name: str
    region: str
    description: str
    durations: tuple[int, ...]
    price_from: int
    best_season: str
    difficulty: str
    color: str
    icon: str
    on_leaflet: bool = True

    def to_dict(self) -> dict:
        data = asdict(self)
        data["durations"] = list(self.durations)
        return data


TRIPS: tuple[Trip, ...] = (
    Trip(
        id="rowerem-przez-afryke",
        name="Rowerem przez Afrykę",
        region="Cały kontynent · RPA, Botswana, Zambia",
        description=(
            "Szutrowe drogi, wioski i horyzont bez końca. Dystans dobieramy do "
            "kondycji grupy, a bagaż jedzie za Wami autem."
        ),
        durations=(14, 21, 28),
        price_from=14210,
        best_season="maj–październik (pora sucha)",
        difficulty="średnia, szutry i piach",
        color="#e2541b",
        icon="bike",
    ),
    Trip(
        id="z-plecakiem-w-serengeti",
        name="Z plecakiem w Serengeti",
        region="Tanzania",
        description=(
            "Piesze trasy z rangerem, noce w obozach pod gwiazdami i Wielka "
            "Migracja widziana z bliska, a nie zza szyby."
        ),
        durations=(10, 14, 18),
        price_from=14250,
        best_season="styczeń–marzec i czerwiec–październik",
        difficulty="średnia, bez wspinaczki",
        color="#1f6f5c",
        icon="backpack",
    ),
    Trip(
        id="afryka-w-obiektywie",
        name="Afryka w obiektywie",
        region="Park Krugera · RPA",
        description=(
            "Fotosafari z fotografem-przewodnikiem: Wielka Piątka o złotej "
            "godzinie, warsztaty w terenie i wieczorne omawianie zdjęć."
        ),
        durations=(10, 12, 16),
        price_from=13965,
        best_season="maj–wrzesień (zwierzęta przy wodopojach)",
        difficulty="niewymagająca",
        color="#c98a00",
        icon="camera",
    ),
    Trip(
        id="afryka-codziennie",
        name="Afryka codziennie",
        region="Masai Mara · Kenia",
        description=(
            "Dzień razem z Masajami: targ, wypas bydła, wspólne gotowanie. "
            "Afryka bez filtra i bez pośpiechu."
        ),
        durations=(10, 14, 21),
        price_from=12065,
        best_season="cały rok; migracja lipiec–październik",
        difficulty="niewymagająca",
        color="#9b2f4a",
        icon="sun",
    ),
    Trip(
        id="kilimandzaro",
        name="Na dach Afryki – Kilimandżaro",
        region="Tanzania",
        description=(
            "Wejście na Uhuru Peak (5895 m) trasą Machame, z aklimatyzacją, "
            "tragarzami i kucharzem."
        ),
        durations=(10, 12, 14),
        price_from=14250,
        best_season="styczeń–marzec i czerwiec–październik",
        difficulty="dobra; doświadczenie górskie mile widziane",
        color="#5b4a8a",
        icon="mountain",
        on_leaflet=False,
    ),
    Trip(
        id="wodospady-wiktorii-okawango",
        name="Wodospady Wiktorii i delta Okawango",
        region="Zambia · Zimbabwe · Botswana",
        description=(
            "Wodospady z obu stron granicy, park Chobe z łodzi i delta Okawango "
            "z wydrążonego czółna mokoro."
        ),
        durations=(10, 14, 18),
        price_from=15675,
        best_season="czerwiec–październik (wysoka woda w delcie)",
        difficulty="niewymagająca",
        color="#1f6d8c",
        icon="water",
        on_leaflet=False,
    ),
)

AIRPORTS: dict[str, str] = {
    "WAW": "Warszawa Chopin",
    "KRK": "Kraków Balice",
    "KTW": "Katowice Pyrzowice",
    "GDN": "Gdańsk",
    "WRO": "Wrocław",
    "POZ": "Poznań",
}

_BY_ID = {trip.id: trip for trip in TRIPS}


def get_trip(trip_id: str) -> Trip | None:
    return _BY_ID.get(trip_id)
