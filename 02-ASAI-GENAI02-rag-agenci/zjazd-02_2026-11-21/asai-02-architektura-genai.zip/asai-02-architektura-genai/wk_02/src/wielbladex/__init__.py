"""Aplikacja Flask biura podróży Wielbłądex."""

from __future__ import annotations

import os
from pathlib import Path

from flask import Flask

from .api import api
from .storage import RegistrationRepository
from .views import views


def create_app(config: dict | None = None) -> Flask:
    app = Flask(__name__)
    default_db = Path(app.instance_path) / "wielbladex.sqlite3"
    app.config.update(
        DATABASE=os.environ.get("WIELBLADEX_DB", str(default_db)),
        JSON_SORT_KEYS=False,
    )
    app.json.ensure_ascii = False
    app.json.sort_keys = False
    if config:
        app.config.update(config)

    if app.config["DATABASE"] != ":memory:":
        Path(app.config["DATABASE"]).parent.mkdir(parents=True, exist_ok=True)
    app.extensions["registrations"] = RegistrationRepository(app.config["DATABASE"])

    app.register_blueprint(views)
    app.register_blueprint(api)
    return app
