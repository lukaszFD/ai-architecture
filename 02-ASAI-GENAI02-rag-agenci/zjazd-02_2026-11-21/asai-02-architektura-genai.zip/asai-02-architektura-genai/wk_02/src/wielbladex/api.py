"""REST API: wycieczki, lotniska i zapisy chęci uczestnictwa."""

from __future__ import annotations

from flask import Blueprint, current_app, jsonify, request

from .catalog import AIRPORTS, TRIPS, get_trip
from .validation import ValidationError, validate_registration

api = Blueprint("api", __name__, url_prefix="/api")


def _repo():
    return current_app.extensions["registrations"]


def _serialize(reg: dict) -> dict:
    trip = get_trip(reg["trip_id"])
    return {
        **reg,
        "trip_name": trip.name if trip else None,
        "departure_airport_name": AIRPORTS.get(reg["departure_airport"]),
    }


def _error(message: str, status: int, **extra):
    return jsonify({"error": message, **extra}), status


def _json_body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else None


@api.errorhandler(ValidationError)
def _validation_failed(exc: ValidationError):
    return _error("Niepoprawne dane formularza.", 422, fields=exc.errors)


# --- wycieczki -------------------------------------------------------------

@api.get("/trips")
def list_trips():
    return jsonify([trip.to_dict() for trip in TRIPS])


@api.get("/trips/<trip_id>")
def trip_detail(trip_id: str):
    trip = get_trip(trip_id)
    if trip is None:
        return _error("Nie znaleziono wycieczki.", 404)
    return jsonify(trip.to_dict())


@api.get("/airports")
def list_airports():
    return jsonify([{"code": code, "name": name} for code, name in AIRPORTS.items()])


# --- zapisy ----------------------------------------------------------------

@api.get("/registrations")
def list_registrations():
    trip_id = request.args.get("trip_id") or None
    if trip_id and get_trip(trip_id) is None:
        return _error("Nie znaleziono wycieczki.", 404)
    return jsonify([_serialize(r) for r in _repo().list(trip_id)])


@api.post("/registrations")
def create_registration():
    payload = _json_body()
    if payload is None:
        return _error("Oczekiwano obiektu JSON.", 400)
    reg = _repo().create(validate_registration(payload))
    resp = jsonify(_serialize(reg))
    resp.status_code = 201
    resp.headers["Location"] = f"/api/registrations/{reg['id']}"
    return resp


@api.get("/registrations/<int:reg_id>")
def get_registration(reg_id: int):
    reg = _repo().get(reg_id)
    if reg is None:
        return _error("Nie znaleziono zapisu.", 404)
    return jsonify(_serialize(reg))


@api.route("/registrations/<int:reg_id>", methods=["PUT", "PATCH"])
def update_registration(reg_id: int):
    current = _repo().get(reg_id)
    if current is None:
        return _error("Nie znaleziono zapisu.", 404)
    payload = _json_body()
    if payload is None:
        return _error("Oczekiwano obiektu JSON.", 400)
    if request.method == "PATCH":
        # Częściowa zmiana: brakujące pola bierzemy z istniejącego zapisu,
        # a zgoda została już udzielona przy tworzeniu.
        payload = {**current, "consent": True, **payload}
    reg = _repo().update(reg_id, validate_registration(payload))
    return jsonify(_serialize(reg))


@api.delete("/registrations/<int:reg_id>")
def delete_registration(reg_id: int):
    if not _repo().delete(reg_id):
        return _error("Nie znaleziono zapisu.", 404)
    return "", 204
