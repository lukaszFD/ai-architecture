// Lista zapisów: GET /api/registrations z filtrem, usuwanie przez DELETE.
(function () {
  const body = document.getElementById("reg-body");
  const filter = document.getElementById("filter-trip");
  const summary = document.getElementById("summary");

  // Polska odmiana: 1 zapis, 2–4 zapisy, 5+ zapisów (ale 22 zapisy, 12 zapisów).
  function plural(n, one, few, many) {
    if (n === 1) return n + " " + one;
    const d = n % 10, h = n % 100;
    return n + " " + (d >= 2 && d <= 4 && (h < 12 || h > 14) ? few : many);
  }

  function cell(text, extra) {
    const td = document.createElement("td");
    td.textContent = text;
    if (extra) {
      const small = document.createElement("small");
      small.textContent = extra;
      td.appendChild(small);
    }
    return td;
  }

  function render(rows) {
    body.innerHTML = "";
    const people = rows.reduce((sum, r) => sum + r.participants, 0);
    summary.textContent = plural(rows.length, "zapis", "zapisy", "zapisów") + " · " + plural(people, "osoba", "osoby", "osób");
    if (!rows.length) {
      const tr = body.insertRow();
      const td = tr.insertCell();
      td.colSpan = 8;
      td.className = "empty";
      td.textContent = "Brak zapisów.";
      return;
    }
    rows.forEach((r) => {
      const tr = document.createElement("tr");
      tr.appendChild(cell(String(r.id)));
      tr.appendChild(cell(r.first_name + " " + r.last_name, r.notes || ""));
      tr.appendChild(cell(r.email, r.phone));
      tr.appendChild(cell(r.trip_name || r.trip_id, r.duration + " dni"));
      tr.appendChild(cell(new Date(r.preferred_date).toLocaleDateString("pl-PL")));
      tr.appendChild(cell(r.departure_airport, r.departure_airport_name || ""));
      tr.appendChild(cell(String(r.participants)));

      const actions = document.createElement("td");
      actions.className = "actions";
      const edit = document.createElement("a");
      edit.className = "btn btn-small btn-ghost";
      edit.href = "/zapisy/" + r.id + "/edycja";
      edit.textContent = "Edytuj";
      const del = document.createElement("button");
      del.className = "btn btn-small btn-danger";
      del.type = "button";
      del.textContent = "Usuń";
      del.addEventListener("click", async () => {
        if (!confirm("Usunąć zapis " + r.first_name + " " + r.last_name + "?")) return;
        const res = await fetch("/api/registrations/" + r.id, { method: "DELETE" });
        if (res.ok) load();
        else alert("Nie udało się usunąć zapisu.");
      });
      actions.append(edit, del);
      tr.appendChild(actions);
      body.appendChild(tr);
    });
  }

  async function load() {
    const q = filter.value ? "?trip_id=" + encodeURIComponent(filter.value) : "";
    const res = await fetch("/api/registrations" + q);
    render(res.ok ? await res.json() : []);
  }

  filter.addEventListener("change", load);
  load();
})();
