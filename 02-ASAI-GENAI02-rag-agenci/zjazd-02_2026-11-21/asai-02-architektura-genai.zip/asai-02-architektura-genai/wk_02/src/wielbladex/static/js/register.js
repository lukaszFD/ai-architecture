// Formularz zapisu: pobiera wycieczki z API, wysyła POST (nowy zapis) albo PUT (edycja).
(function () {
  const form = document.getElementById("reg-form");
  const regId = form.dataset.regId;
  const alertBox = document.getElementById("form-alert");
  const tripSelect = form.elements.trip_id;
  const durationSelect = form.elements.duration;
  const tripInfo = document.getElementById("trip-info");
  let trips = [];

  const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
  form.elements.preferred_date.min = tomorrow;

  function showAlert(text, ok) {
    alertBox.textContent = text;
    alertBox.className = "alert " + (ok ? "ok" : "err");
    alertBox.hidden = false;
  }

  function clearErrors() {
    form.querySelectorAll(".field-error[data-generated]").forEach((el) => el.remove());
    form.querySelectorAll(".invalid").forEach((el) => el.classList.remove("invalid"));
    form.querySelector('.field-error[data-for="consent"]').textContent = "";
  }

  function showErrors(fields) {
    Object.entries(fields).forEach(([name, message]) => {
      if (name === "consent") {
        form.querySelector('.field-error[data-for="consent"]').textContent = message;
        return;
      }
      const input = form.elements[name];
      if (!input) return;
      const label = input.closest("label");
      label.classList.add("invalid");
      const p = document.createElement("p");
      p.className = "field-error";
      p.dataset.generated = "1";
      p.textContent = message;
      label.after(p);
    });
    const first = form.querySelector(".invalid input, .invalid select, .invalid textarea");
    if (first) first.focus();
  }

  function fillDurations(selected) {
    const trip = trips.find((t) => t.id === tripSelect.value);
    durationSelect.innerHTML = "";
    if (!trip) {
      durationSelect.add(new Option("najpierw wybierz wycieczkę", ""));
      tripInfo.hidden = true;
      return;
    }
    trip.durations.forEach((d) => durationSelect.add(new Option(d + " dni", d)));
    if (selected) durationSelect.value = String(selected);
    tripInfo.textContent =
      trip.region + " · najlepszy termin: " + trip.best_season + " · kondycja: " + trip.difficulty +
      " · cena od " + trip.price_from.toLocaleString("pl-PL") + " zł za osobę";
    tripInfo.hidden = false;
  }

  async function loadTrips() {
    const res = await fetch("/api/trips");
    trips = await res.json();
    tripSelect.innerHTML = "";
    tripSelect.add(new Option("wybierz wycieczkę", ""));
    trips.forEach((t) => tripSelect.add(new Option(t.name + " – " + t.region, t.id)));
  }

  async function loadRegistration() {
    const res = await fetch("/api/registrations/" + regId);
    if (!res.ok) {
      showAlert("Nie znaleziono zapisu.", false);
      return;
    }
    const reg = await res.json();
    ["first_name", "last_name", "email", "phone", "trip_id", "preferred_date",
      "departure_airport", "participants", "notes"].forEach((k) => {
      form.elements[k].value = reg[k] ?? "";
    });
    fillDurations(reg.duration);
  }

  function payload() {
    const f = form.elements;
    return {
      first_name: f.first_name.value,
      last_name: f.last_name.value,
      email: f.email.value,
      phone: f.phone.value,
      trip_id: f.trip_id.value,
      duration: f.duration.value ? Number(f.duration.value) : null,
      preferred_date: f.preferred_date.value,
      departure_airport: f.departure_airport.value,
      participants: f.participants.value ? Number(f.participants.value) : null,
      notes: f.notes.value,
      consent: f.consent.checked,
    };
  }

  tripSelect.addEventListener("change", () => fillDurations());

  form.addEventListener("submit", async (event) => {
    event.preventDefault();
    clearErrors();
    alertBox.hidden = true;
    const button = form.querySelector('button[type="submit"]');
    button.disabled = true;
    try {
      const res = await fetch(regId ? "/api/registrations/" + regId : "/api/registrations", {
        method: regId ? "PUT" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload()),
      });
      const data = await res.json().catch(() => ({}));
      if (res.ok) {
        if (regId) {
          showAlert("Zmiany zapisane.", true);
        } else {
          showAlert(
            "Dziękujemy, " + data.first_name + "! Zgłoszenie nr " + data.id + " na wyprawę „" +
            data.trip_name + "” jest przyjęte. Odezwiemy się, żeby umówić bezpłatną konsultację.", true);
          form.reset();
          fillDurations();
        }
      } else if (res.status === 422 && data.fields) {
        showErrors(data.fields);
        showAlert("Popraw zaznaczone pola.", false);
      } else {
        showAlert(data.error || "Coś poszło nie tak. Spróbuj ponownie.", false);
      }
    } catch (err) {
      showAlert("Brak połączenia z serwerem.", false);
    } finally {
      button.disabled = false;
    }
  });

  loadTrips().then(() => {
    if (regId) return loadRegistration();
    const preselected = new URLSearchParams(location.search).get("wycieczka");
    if (preselected) {
      tripSelect.value = preselected;
      fillDurations();
    }
  });
})();
