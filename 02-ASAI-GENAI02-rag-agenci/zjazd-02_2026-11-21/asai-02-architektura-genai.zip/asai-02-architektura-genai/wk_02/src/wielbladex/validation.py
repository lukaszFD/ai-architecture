"""Walidacja danych z formularza zapisu."""

from __future__ import annotations

import re
from datetime import date

from .catalog import AIRPORTS, get_trip

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
PHONE_RE = re.compile(r"^\+?[0-9][0-9 \-]{7,18}$")
MAX_GROUP = 10

FIELDS = (
    "first_name", "last_name", "email", "phone", "trip_id", "duration",
    "preferred_date", "departure_airport", "participants", "notes", "consent",
)


class ValidationError(Exception):
    def __init__(self, errors: dict[str, str]):
        super().__init__("Niepoprawne dane formularza")
        self.errors = errors


def _text(value, field, errors, *, required=True, max_len=100):
    value = "" if value is None else str(value).strip()
    if required and not value:
        errors[field] = "Pole jest wymagane."
    elif len(value) > max_len:
        errors[field] = f"Maksymalnie {max_len} znaków."
    return value


def _int(value, field, errors):
    if isinstance(value, bool):
        errors[field] = "Podaj liczbę całkowitą."
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        errors[field] = "Podaj liczbę całkowitą."
        return None


def validate_registration(payload: dict, *, today: date | None = None) -> dict:
    """Zwraca oczyszczone dane albo rzuca ValidationError ze słownikiem błędów."""
    if not isinstance(payload, dict):
        raise ValidationError({"_": "Oczekiwano obiektu JSON."})
    today = today or date.today()
    errors: dict[str, str] = {}
    clean: dict = {}

    clean["first_name"] = _text(payload.get("first_name"), "first_name", errors, max_len=60)
    clean["last_name"] = _text(payload.get("last_name"), "last_name", errors, max_len=80)

    email = _text(payload.get("email"), "email", errors, max_len=120).lower()
    if email and "email" not in errors and not EMAIL_RE.match(email):
        errors["email"] = "Niepoprawny adres e-mail."
    clean["email"] = email

    phone = _text(payload.get("phone"), "phone", errors, max_len=20)
    if phone and "phone" not in errors and not PHONE_RE.match(phone):
        errors["phone"] = "Niepoprawny numer telefonu."
    clean["phone"] = phone

    trip_id = _text(payload.get("trip_id"), "trip_id", errors)
    trip = get_trip(trip_id) if trip_id else None
    if trip_id and trip is None:
        errors["trip_id"] = "Nieznana wycieczka."
    clean["trip_id"] = trip_id

    duration = _int(payload.get("duration"), "duration", errors)
    if duration is not None and trip is not None and duration not in trip.durations:
        allowed = ", ".join(map(str, trip.durations))
        errors["duration"] = f"Dla tej wycieczki dostępne są warianty: {allowed} dni."
    clean["duration"] = duration

    raw_date = _text(payload.get("preferred_date"), "preferred_date", errors, max_len=10)
    if raw_date and "preferred_date" not in errors:
        try:
            preferred = date.fromisoformat(raw_date)
        except ValueError:
            errors["preferred_date"] = "Podaj datę w formacie RRRR-MM-DD."
        else:
            if preferred <= today:
                errors["preferred_date"] = "Preferowany termin musi być w przyszłości."
    clean["preferred_date"] = raw_date

    airport = _text(payload.get("departure_airport"), "departure_airport", errors, max_len=3).upper()
    if airport and airport not in AIRPORTS:
        errors["departure_airport"] = "Wybierz lotnisko z listy."
    clean["departure_airport"] = airport

    participants = _int(payload.get("participants", 1), "participants", errors)
    if participants is not None and not 1 <= participants <= MAX_GROUP:
        errors["participants"] = f"Liczba osób: od 1 do {MAX_GROUP}."
    clean["participants"] = participants

    clean["notes"] = _text(payload.get("notes"), "notes", errors, required=False, max_len=1000)

    if payload.get("consent") is not True:
        errors["consent"] = "Zgoda na przetwarzanie danych jest wymagana."
    clean["consent"] = True

    if errors:
        raise ValidationError(errors)
    return clean
