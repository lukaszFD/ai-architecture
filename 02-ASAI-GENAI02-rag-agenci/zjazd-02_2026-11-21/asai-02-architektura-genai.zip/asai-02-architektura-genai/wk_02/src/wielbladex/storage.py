"""Repozytorium zapisów oparte na SQLite (biblioteka standardowa)."""

from __future__ import annotations

import sqlite3
from datetime import datetime, timezone

SCHEMA = """
CREATE TABLE IF NOT EXISTS registrations (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name        TEXT NOT NULL,
    last_name         TEXT NOT NULL,
    email             TEXT NOT NULL,
    phone             TEXT NOT NULL,
    trip_id           TEXT NOT NULL,
    duration          INTEGER NOT NULL,
    preferred_date    TEXT NOT NULL,
    departure_airport TEXT NOT NULL,
    participants      INTEGER NOT NULL DEFAULT 1,
    notes             TEXT NOT NULL DEFAULT '',
    created_at        TEXT NOT NULL,
    updated_at        TEXT NOT NULL
)
"""

COLUMNS = (
    "first_name", "last_name", "email", "phone", "trip_id", "duration",
    "preferred_date", "departure_airport", "participants", "notes",
)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class RegistrationRepository:
    def __init__(self, db_path: str):
        self.db_path = db_path
        # Baza w pamięci żyje tylko tak długo jak połączenie, więc trzymamy jedno.
        self._shared = sqlite3.connect(":memory:", check_same_thread=False) if db_path == ":memory:" else None
        with self._connect() as conn:
            conn.execute(SCHEMA)

    def _connect(self) -> sqlite3.Connection:
        conn = self._shared or sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _run(self, sql: str, params=()):
        conn = self._connect()
        try:
            with conn:
                return conn.execute(sql, params)
        finally:
            if conn is not self._shared:
                conn.close()

    def _fetch(self, sql: str, params=()) -> list[dict]:
        conn = self._connect()
        try:
            return [dict(row) for row in conn.execute(sql, params).fetchall()]
        finally:
            if conn is not self._shared:
                conn.close()

    def create(self, data: dict) -> dict:
        now = _now()
        values = [data[c] for c in COLUMNS]
        cur = self._run(
            f"INSERT INTO registrations ({', '.join(COLUMNS)}, created_at, updated_at) "
            f"VALUES ({', '.join('?' * len(COLUMNS))}, ?, ?)",
            (*values, now, now),
        )
        return self.get(cur.lastrowid)

    def get(self, reg_id: int) -> dict | None:
        rows = self._fetch("SELECT * FROM registrations WHERE id = ?", (reg_id,))
        return rows[0] if rows else None

    def list(self, trip_id: str | None = None) -> list[dict]:
        if trip_id:
            return self._fetch(
                "SELECT * FROM registrations WHERE trip_id = ? ORDER BY created_at, id", (trip_id,)
            )
        return self._fetch("SELECT * FROM registrations ORDER BY created_at, id")

    def update(self, reg_id: int, data: dict) -> dict | None:
        if self.get(reg_id) is None:
            return None
        assignments = ", ".join(f"{c} = ?" for c in COLUMNS)
        self._run(
            f"UPDATE registrations SET {assignments}, updated_at = ? WHERE id = ?",
            (*[data[c] for c in COLUMNS], _now(), reg_id),
        )
        return self.get(reg_id)

    def delete(self, reg_id: int) -> bool:
        return self._run("DELETE FROM registrations WHERE id = ?", (reg_id,)).rowcount > 0
