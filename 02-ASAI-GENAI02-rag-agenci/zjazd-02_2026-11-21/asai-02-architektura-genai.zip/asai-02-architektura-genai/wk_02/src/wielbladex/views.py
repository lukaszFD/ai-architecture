"""Strony HTML. Formularz i lista rozmawiają z backendem przez REST API."""

from __future__ import annotations

from flask import Blueprint, abort, current_app, render_template

from .catalog import AIRPORTS, TRIPS

views = Blueprint("views", __name__)


@views.get("/")
def index():
    return render_template("index.html", trips=TRIPS)


@views.get("/zapisy")
def register():
    return render_template("register.html", airports=AIRPORTS, reg_id=None)


@views.get("/zapisy/<int:reg_id>/edycja")
def edit(reg_id: int):
    if current_app.extensions["registrations"].get(reg_id) is None:
        abort(404)
    return render_template("register.html", airports=AIRPORTS, reg_id=reg_id)


@views.get("/zapisy/lista")
def registrations():
    return render_template("registrations.html", trips=TRIPS)
