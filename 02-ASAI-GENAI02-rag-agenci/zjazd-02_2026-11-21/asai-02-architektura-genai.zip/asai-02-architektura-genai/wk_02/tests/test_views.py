def test_home_page_shows_leaflet_content_and_trips(client):
    html = client.get("/").get_data(as_text=True)
    assert "Afryka szyta" in html
    assert "Travel Concierge" in html
    for name in ("Rowerem przez Afrykę", "Z plecakiem w Serengeti", "Afryka w obiektywie", "Afryka codziennie"):
        assert name in html
    assert "od 14 210 zł" in html


def test_register_page_has_form_fields(client):
    html = client.get("/zapisy").get_data(as_text=True)
    for field in ("first_name", "last_name", "email", "phone", "trip_id", "duration",
                  "preferred_date", "departure_airport", "consent"):
        assert f'name="{field}"' in html
    assert "Katowice Pyrzowice (KTW)" in html


def test_edit_page_only_for_existing_registration(client, payload):
    assert client.get("/zapisy/1/edycja").status_code == 404
    client.post("/api/registrations", json=payload)
    html = client.get("/zapisy/1/edycja").get_data(as_text=True)
    assert 'data-reg-id="1"' in html
    assert "Zapisz zmiany" in html


def test_registrations_page(client):
    res = client.get("/zapisy/lista")
    assert res.status_code == 200
    assert "Lista" in res.get_data(as_text=True)


def test_static_assets(client):
    for path in ("/static/css/style.css", "/static/js/register.js",
                 "/static/js/registrations.js", "/static/img/logo.jpg"):
        assert client.get(path).status_code == 200
