import pytest

from wielbladex import create_app


@pytest.fixture
def app(tmp_path):
    return create_app({"TESTING": True, "DATABASE": str(tmp_path / "test.sqlite3")})


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def payload():
    return {
        "first_name": "Janina",
        "last_name": "Wielbłądek",
        "email": "janina@example.com",
        "phone": "+48 600 000 000",
        "trip_id": "rowerem-przez-afryke",
        "duration": 14,
        "preferred_date": "2099-06-01",
        "departure_airport": "KTW",
        "participants": 2,
        "notes": "Własny rower",
        "consent": True,
    }
