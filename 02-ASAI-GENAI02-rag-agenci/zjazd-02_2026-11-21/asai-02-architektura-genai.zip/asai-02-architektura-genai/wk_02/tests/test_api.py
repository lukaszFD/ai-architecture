from wielbladex.catalog import AIRPORTS, TRIPS


def create(client, payload):
    return client.post("/api/registrations", json=payload)


# --- wycieczki i lotniska

def test_list_trips(client):
    res = client.get("/api/trips")
    assert res.status_code == 200
    data = res.get_json()
    assert len(data) == len(TRIPS)
    assert data[0]["name"] == "Rowerem przez Afrykę"
    assert data[0]["durations"] == [14, 21, 28]


def test_trip_detail_and_404(client):
    assert client.get("/api/trips/kilimandzaro").get_json()["price_from"] == 14250
    res = client.get("/api/trips/nie-ma")
    assert res.status_code == 404
    assert "error" in res.get_json()


def test_list_airports(client):
    data = client.get("/api/airports").get_json()
    assert {a["code"] for a in data} == set(AIRPORTS)


# --- zapisy: tworzenie

def test_create_registration(client, payload):
    res = create(client, payload)
    assert res.status_code == 201
    body = res.get_json()
    assert body["id"] == 1
    assert body["trip_name"] == "Rowerem przez Afrykę"
    assert body["departure_airport_name"] == "Katowice Pyrzowice"
    assert res.headers["Location"] == "/api/registrations/1"
    assert "consent" not in body


def test_create_returns_field_errors(client, payload):
    payload.update(email="zly", duration=99)
    res = create(client, payload)
    assert res.status_code == 422
    assert set(res.get_json()["fields"]) == {"email", "duration"}


def test_create_requires_json_object(client):
    assert client.post("/api/registrations", data="x", content_type="text/plain").status_code == 400
    assert client.post("/api/registrations", json=[1, 2]).status_code == 400


# --- zapisy: lista

def test_list_registrations_with_filter(client, payload):
    create(client, payload)
    create(client, {**payload, "trip_id": "afryka-codziennie", "duration": 10})
    assert len(client.get("/api/registrations").get_json()) == 2
    filtered = client.get("/api/registrations?trip_id=afryka-codziennie").get_json()
    assert [r["trip_id"] for r in filtered] == ["afryka-codziennie"]
    assert client.get("/api/registrations?trip_id=nie-ma").status_code == 404


def test_get_registration(client, payload):
    create(client, payload)
    assert client.get("/api/registrations/1").get_json()["email"] == "janina@example.com"
    assert client.get("/api/registrations/2").status_code == 404


# --- zapisy: modyfikacja

def test_put_replaces_registration(client, payload):
    create(client, payload)
    res = client.put("/api/registrations/1", json={**payload, "departure_airport": "WAW", "participants": 3})
    assert res.status_code == 200
    body = res.get_json()
    assert body["departure_airport"] == "WAW"
    assert body["participants"] == 3


def test_put_validates_full_payload(client, payload):
    create(client, payload)
    res = client.put("/api/registrations/1", json={"participants": 3})
    assert res.status_code == 422
    assert "first_name" in res.get_json()["fields"]


def test_patch_changes_only_given_fields(client, payload):
    create(client, payload)
    res = client.patch("/api/registrations/1", json={"preferred_date": "2099-09-15"})
    assert res.status_code == 200
    body = res.get_json()
    assert body["preferred_date"] == "2099-09-15"
    assert body["last_name"] == "Wielbłądek"


def test_patch_validates_merged_data(client, payload):
    create(client, payload)
    res = client.patch("/api/registrations/1", json={"trip_id": "kilimandzaro"})  # 14 dni pasuje
    assert res.status_code == 200
    res = client.patch("/api/registrations/1", json={"duration": 28})  # Kilimandżaro: 10/12/14
    assert res.status_code == 422


def test_update_missing_registration(client, payload):
    assert client.put("/api/registrations/5", json=payload).status_code == 404
    assert client.patch("/api/registrations/5", json={}).status_code == 404


def test_update_requires_json(client, payload):
    create(client, payload)
    assert client.patch("/api/registrations/1", data="x", content_type="text/plain").status_code == 400


# --- zapisy: usuwanie

def test_delete_registration(client, payload):
    create(client, payload)
    assert client.delete("/api/registrations/1").status_code == 204
    assert client.delete("/api/registrations/1").status_code == 404
    assert client.get("/api/registrations").get_json() == []
