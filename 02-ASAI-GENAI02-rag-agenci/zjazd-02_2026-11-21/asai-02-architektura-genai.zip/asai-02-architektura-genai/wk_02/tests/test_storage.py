import pytest

from wielbladex.storage import RegistrationRepository


@pytest.fixture(params=["file", "memory"])
def repo(request, tmp_path):
    path = str(tmp_path / "r.sqlite3") if request.param == "file" else ":memory:"
    return RegistrationRepository(path)


def data(**over):
    base = dict(first_name="Jan", last_name="Kowalski", email="jan@example.com", phone="600000000",
                trip_id="afryka-codziennie", duration=10, preferred_date="2099-01-10",
                departure_airport="WAW", participants=1, notes="")
    return {**base, **over}


def test_create_and_get(repo):
    reg = repo.create(data())
    assert reg["id"] == 1
    assert reg["created_at"] == reg["updated_at"]
    assert repo.get(1)["last_name"] == "Kowalski"


def test_get_missing_returns_none(repo):
    assert repo.get(42) is None


def test_list_and_filter(repo):
    repo.create(data())
    repo.create(data(trip_id="kilimandzaro", duration=12))
    assert len(repo.list()) == 2
    assert [r["trip_id"] for r in repo.list("kilimandzaro")] == ["kilimandzaro"]


def test_update(repo):
    repo.create(data())
    updated = repo.update(1, data(participants=4))
    assert updated["participants"] == 4
    assert repo.update(99, data()) is None


def test_delete(repo):
    repo.create(data())
    assert repo.delete(1) is True
    assert repo.delete(1) is False
    assert repo.list() == []


def test_data_survives_new_repository_instance(tmp_path):
    path = str(tmp_path / "persist.sqlite3")
    RegistrationRepository(path).create(data())
    assert len(RegistrationRepository(path).list()) == 1
