from datetime import date

import pytest

from wielbladex.validation import ValidationError, validate_registration

TODAY = date(2026, 11, 22)


def errors_for(data):
    with pytest.raises(ValidationError) as exc:
        validate_registration(data, today=TODAY)
    return exc.value.errors


def test_valid_payload_is_cleaned(payload):
    payload.update(email="  JANINA@Example.com ", departure_airport="ktw", first_name=" Janina ")
    clean = validate_registration(payload, today=TODAY)
    assert clean["email"] == "janina@example.com"
    assert clean["departure_airport"] == "KTW"
    assert clean["first_name"] == "Janina"


def test_missing_required_fields():
    errs = errors_for({})
    for field in ("first_name", "last_name", "email", "phone", "trip_id",
                  "preferred_date", "departure_airport", "consent"):
        assert field in errs


@pytest.mark.parametrize("email", ["janina", "janina@", "a b@c.pl", "janina@example"])
def test_invalid_email(payload, email):
    payload["email"] = email
    assert "email" in errors_for(payload)


@pytest.mark.parametrize("phone", ["abc", "123", "+48 abc 000 000"])
def test_invalid_phone(payload, phone):
    payload["phone"] = phone
    assert "phone" in errors_for(payload)


def test_unknown_trip(payload):
    payload["trip_id"] = "na-ksiezyc"
    assert errors_for(payload)["trip_id"] == "Nieznana wycieczka."


def test_duration_must_match_trip_variant(payload):
    payload["duration"] = 10  # rower ma warianty 14 / 21 / 28
    assert "14, 21, 28" in errors_for(payload)["duration"]


@pytest.mark.parametrize("value", ["2026-11-22", "2020-01-01", "22.11.2027", "jutro"])
def test_preferred_date_must_be_future_iso(payload, value):
    payload["preferred_date"] = value
    assert "preferred_date" in errors_for(payload)


def test_unknown_airport(payload):
    payload["departure_airport"] = "JFK"
    assert "departure_airport" in errors_for(payload)


@pytest.mark.parametrize("value", [0, 11, "dwie", True])
def test_participants_range(payload, value):
    payload["participants"] = value
    assert "participants" in errors_for(payload)


@pytest.mark.parametrize("value", [False, "true", None])
def test_consent_must_be_true(payload, value):
    payload["consent"] = value
    assert "consent" in errors_for(payload)


def test_notes_length_limit(payload):
    payload["notes"] = "x" * 1001
    assert "notes" in errors_for(payload)


def test_non_dict_payload():
    with pytest.raises(ValidationError):
        validate_registration(["nie", "słownik"])
